package com.example.wallpaper;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends Activity implements OnClickListener{
Button b1,b2;
RadioButton rb1,rb2,rb3,rb4;
RadioGroup rg;
int changeTime=60;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		b1=(Button)findViewById(R.id.button1);
		b2=(Button)findViewById(R.id.button2);
		rb1=(RadioButton)findViewById(R.id.radio0);
		rb2=(RadioButton)findViewById(R.id.radio1);
		rb3=(RadioButton)findViewById(R.id.radio2);
		rb4=(RadioButton)findViewById(R.id.radio3);
		rg=(RadioGroup)findViewById(R.id.radioGroup1);
		b1.setOnClickListener(this);
		b2.setOnClickListener(this);
		rg.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		
		if(v.getId()==b1.getId())
		{
			
		int mradioid=rg.getCheckedRadioButtonId();
		if(rb1.getId()==mradioid)
         		{
			
			changeTime=60;
	         	}
			
		else if(rb2.getId()==mradioid)
 		      {
	
				changeTime=5*60;
 		      }
		else if(rb3.getId()==mradioid)
 			{
			
				changeTime=10*60;
 			}
		else{
		
				changeTime=20*60;
         	}
		
		Bundle mbundle=new Bundle();
		mbundle.putInt("time",changeTime);
		Intent inservice=new Intent(this,WallpaperService.class);
	    inservice.putExtras(mbundle);
	    startService(inservice);
	    finish();
	
		}
		else
		{
			stopService(new Intent(this,WallpaperService.class));
			finish();
			
		}
		
		
		
		
		
	}

}
