package com.example.wallpaper;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.IBinder;


public class WallpaperService extends Service implements Runnable {
private int wallpaperid[]={R.drawable.img1,R.drawable.img2};
private Bitmap bitmap,bitmap1;
private Thread t=null;
private int flag=0;
private int time;
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
	
		
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		System.exit(0);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		
		super.onStartCommand(intent, flags, startId);
		Bundle b=intent.getExtras();
		time=b.getInt("time");
		bitmap=BitmapFactory.
				decodeResource(getResources(),wallpaperid[0]);
		
		bitmap1=BitmapFactory.
				decodeResource(getResources(),wallpaperid[1]);
		
		t=new Thread(WallpaperService.this);
		t.start();
		
		
		return 0;
	}
	public void run()
	{
		try{
			while(true)
			{
				if(flag==0)
				{
					this.setWallpaper(bitmap);
					flag++;
					
				}
				else
				{
					this.setWallpaper(bitmap1);
					flag--;
					
				}
				Thread.sleep(1000*time);
				
			}
			
		}
		catch(Exception e)
		{
			
			
			e.printStackTrace();
		}
		
		
	}
	

}








